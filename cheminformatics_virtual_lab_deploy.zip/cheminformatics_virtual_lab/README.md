# Cheminformatics Virtual Laboratory

A Streamlit educational app for molecular visualization and cheminformatics using RDKit, py3Dmol, pandas, Matplotlib, and ReportLab.

## Deploy online for free with Streamlit Community Cloud

1. Create/sign in to a GitHub account: https://github.com
2. Create a **new public repository** (for example `cheminformatics-virtual-lab`).
3. Upload `app.py`, `requirements.txt`, and this `README.md` from this folder to the repository root.
4. Open https://share.streamlit.io/ and sign in with GitHub.
5. Choose **Create app**, select your repository and branch (`main`), and set the app file path to `app.py`.
6. Open **Advanced settings** and choose Python **3.12** if the option is available.
7. Click **Deploy** and wait for dependency installation to finish. Streamlit will provide a shareable `*.streamlit.app` URL.

## Run locally on Windows

Open PowerShell in this folder and run:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

If PowerShell blocks virtual-environment activation, run the install and app commands from Command Prompt after activating `.venv\Scripts\activate.bat`.

## Notes

- `srm_logo.jpeg` is optional. The app will show no logo if that file is absent. If you have permission to use the college logo, upload it alongside `app.py` using that exact filename.
- The first cloud build may take several minutes because RDKit includes compiled scientific libraries.
- This source was checked for Python syntax, but a successful cloud deployment can only be confirmed after Streamlit Community Cloud installs the dependencies and starts the app.
